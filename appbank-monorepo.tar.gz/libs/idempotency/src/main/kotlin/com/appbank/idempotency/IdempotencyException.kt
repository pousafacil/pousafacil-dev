package com.appbank.idempotency

class IdempotencyConflictException(message: String): RuntimeException(message)

