export default function Dashboard() {
  return (
    <main style={{ padding: 24 }}>
      <h2>Dashboard</h2>
      <p>Bem-vindo ao AppBank. Selecione uma operação.</p>
    </main>
  );
}

